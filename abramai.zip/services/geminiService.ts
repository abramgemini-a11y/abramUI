import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { Subject } from "../types";

// Helper to convert file to Base64
export const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      // Remove data url prefix (e.g. "data:image/jpeg;base64,") to get just the base64 data
      const base64Data = result.split(',')[1]; 
      resolve(base64Data);
    };
    reader.onerror = (error) => reject(error);
    reader.readAsDataURL(file);
  });
};

const getSystemInstruction = (subject: Subject): string => {
  switch (subject) {
    case Subject.ALGEBRA:
    case Subject.PHYSICS:
    case Subject.CHEMISTRY:
      return `Ты — AbramAI, эксперт по предмету ${subject}.
      КРИТИЧЕСКИ ВАЖНАЯ ИНСТРУКЦИЯ: Твоя цель — помочь ученику выполнить домашнее задание.
      ПРАВИЛО ВЫВОДА: Пиши ИСКЛЮЧИТЕЛЬНО то, что ученик должен переписать в тетрадь.
      - НЕ используй вводные фразы типа "Конечно, вот решение", "Привет" или "Давайте решим".
      - Давай сразу чистовое, четкое, пошаговое решение.
      - Используй стандартное форматирование для уравнений (LaTeX в $ или $$).
      - Если пользователь присылает изображение, реши задачу с изображения, следуя тем же правилам.
      - Если условие задачи неполное или непонятное, задай короткий уточняющий вопрос.`;
    
    case Subject.HISTORY:
      return `Ты — AbramAI, эксперт-историк.
      КРИТИЧЕСКИ ВАЖНАЯ ИНСТРУКЦИЯ: Твоя цель — составить качественный конспект для ученика по теме.
      ПРАВИЛО ВЫВОДА:
      - Структурируй материал, используй заголовки.
      - Используй маркированные списки для ключевых событий.
      - Выделяй жирным шрифтом важные даты, имена и термины.
      - Стиль должен быть образовательным, кратким и информативным.
      - НЕ используй разговорные вводные фразы. Только конспект.`;
      
    default:
      return "Ты — AbramAI, полезный образовательный помощник.";
  }
};

export const sendMessageToGemini = async (
  prompt: string,
  subject: Subject,
  imageBase64?: string
): Promise<string> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    const modelName = 'gemini-2.5-flash';

    const systemInstruction = getSystemInstruction(subject);

    const parts: any[] = [];
    
    if (imageBase64) {
      parts.push({
        inlineData: {
          mimeType: 'image/jpeg', // Assuming JPEG for simplicity, GenAI handles most types
          data: imageBase64
        }
      });
    }

    if (prompt) {
      parts.push({ text: prompt });
    }

    const response: GenerateContentResponse = await ai.models.generateContent({
      model: modelName,
      contents: {
        role: 'user',
        parts: parts
      },
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.4, // Lower temperature for more deterministic/factual outputs
      }
    });

    return response.text || "Извините, не удалось сгенерировать ответ.";

  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Ошибка связи с AbramAI. Пожалуйста, попробуйте еще раз.";
  }
};