import React from 'react';
import ReactMarkdown from 'react-markdown';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';
import { Message } from '../types';
import { Bot, User } from 'lucide-react';

interface ChatMessageProps {
  message: Message;
}

const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
  const isUser = message.role === 'user';

  return (
    <div className={`flex w-full mb-8 ${isUser ? 'justify-end' : 'justify-start'} animate-in fade-in slide-in-from-bottom-4 duration-500`}>
      <div className={`flex max-w-[85%] md:max-w-[75%] items-end gap-3 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}>
        
        {/* Avatar */}
        <div className={`
          flex-shrink-0 w-8 h-8 rounded-xl flex items-center justify-center
          shadow-lg backdrop-blur-sm border border-white/10
          ${isUser 
            ? 'bg-gradient-to-br from-indigo-500 to-purple-600' 
            : 'bg-slate-800/80'}
        `}>
          {isUser ? <User size={14} className="text-white" /> : <Bot size={14} className="text-emerald-400" />}
        </div>

        {/* Bubble */}
        <div className={`
          relative px-6 py-4 rounded-3xl text-sm md:text-base shadow-xl backdrop-blur-md
          ${isUser 
            ? 'bg-gradient-to-br from-indigo-600 to-violet-600 text-white rounded-br-none border border-indigo-500/30' 
            : 'bg-slate-800/60 border border-white/10 text-slate-100 rounded-bl-none hover:bg-slate-800/70 transition-colors'}
        `}>
          
          {/* User Image Display */}
          {message.image && (
            <div className="mb-4 rounded-xl overflow-hidden border border-white/10 shadow-md">
              <img 
                src={`data:image/jpeg;base64,${message.image}`} 
                alt="User upload" 
                className="max-w-full max-h-80 object-cover hover:scale-105 transition-transform duration-500"
              />
            </div>
          )}

          {/* Text Content with Markdown */}
          <div className="markdown-body">
            <ReactMarkdown
              remarkPlugins={[remarkMath]}
              rehypePlugins={[rehypeKatex]}
              components={{
                code({node, inline, className, children, ...props}: any) {
                  return !inline ? (
                    <div className="bg-black/40 backdrop-blur rounded-lg p-3 my-3 overflow-x-auto text-xs font-mono border border-white/5 shadow-inner">
                      <code {...props} className={className}>
                        {children}
                      </code>
                    </div>
                  ) : (
                    <code {...props} className="bg-white/10 rounded px-1.5 py-0.5 text-[0.9em] font-mono border border-white/5">
                      {children}
                    </code>
                  )
                }
              }}
            >
              {message.content}
            </ReactMarkdown>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatMessage;