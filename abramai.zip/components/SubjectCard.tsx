import React from 'react';
import { Subject } from '../types';
import { BookOpen, Calculator, FlaskConical, Atom } from 'lucide-react';

interface SubjectCardProps {
  subject: Subject;
  isActive: boolean;
  onClick: (subject: Subject) => void;
}

const SubjectCard: React.FC<SubjectCardProps> = ({ subject, isActive, onClick }) => {
  const getIcon = () => {
    switch (subject) {
      case Subject.ALGEBRA: return <Calculator className="w-5 h-5" />;
      case Subject.HISTORY: return <BookOpen className="w-5 h-5" />;
      case Subject.CHEMISTRY: return <FlaskConical className="w-5 h-5" />;
      case Subject.PHYSICS: return <Atom className="w-5 h-5" />;
    }
  };

  const getActiveStyles = () => {
    switch (subject) {
      case Subject.ALGEBRA: 
        return 'bg-gradient-to-r from-blue-600/20 to-cyan-500/20 border-blue-500/50 text-blue-100 shadow-[0_0_20px_rgba(59,130,246,0.15)]';
      case Subject.HISTORY: 
        return 'bg-gradient-to-r from-amber-600/20 to-orange-500/20 border-amber-500/50 text-amber-100 shadow-[0_0_20px_rgba(245,158,11,0.15)]';
      case Subject.CHEMISTRY: 
        return 'bg-gradient-to-r from-emerald-600/20 to-teal-500/20 border-emerald-500/50 text-emerald-100 shadow-[0_0_20px_rgba(16,185,129,0.15)]';
      case Subject.PHYSICS: 
        return 'bg-gradient-to-r from-violet-600/20 to-purple-500/20 border-violet-500/50 text-violet-100 shadow-[0_0_20px_rgba(139,92,246,0.15)]';
    }
  };

  return (
    <button
      onClick={() => onClick(subject)}
      className={`
        relative group flex items-center gap-3 p-3.5 rounded-2xl w-full mb-3
        transition-all duration-300 ease-out border
        ${isActive 
          ? `${getActiveStyles()} translate-x-1` 
          : 'bg-white/5 border-transparent text-slate-400 hover:bg-white/10 hover:text-slate-200 hover:border-white/10'}
      `}
    >
      <div className={`
        p-2 rounded-xl transition-all duration-300
        ${isActive ? 'bg-white/10 scale-110' : 'bg-black/20 group-hover:bg-black/30'}
      `}>
        {getIcon()}
      </div>
      
      <span className={`text-sm font-medium tracking-wide ${isActive ? 'font-semibold' : ''}`}>
        {subject}
      </span>

      {isActive && (
        <div className="absolute right-4 flex space-x-1">
          <div className="w-1.5 h-1.5 rounded-full bg-white/70 animate-pulse"></div>
        </div>
      )}
    </button>
  );
};

export default SubjectCard;